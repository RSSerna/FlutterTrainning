package com.example.formulario_arq

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
