// ignore: depend_on_referenced_packages
import 'package:meta/meta.dart';
import 'package:bloc/bloc.dart';
import 'package:http/http.dart' as http;

import 'package:formulario_arq/model/api_response.dart';

part 'api_event.dart';
part 'api_state.dart';

class ApiBloc extends Bloc<ApiEvent, ApiState> {
  final String _baseUrl = '127.0.0.1:8000';

  ApiBloc() : super(ApiInitialState()) {

    on<NewApiResponseEvent>((event, emit) {
      emit(ApiSetState(apiResponseNew: event.apiResponse));

      //TODO: Logica New ApiResponse
    });
    on<ModifyApiResponseEvent>((event, emit) {
      emit(ApiSetState(apiResponseNew: event.apiResponse));

      //TODO: Logica New ApiResponse
    });

    on<SearchApiResponseEvent>((event, emit) async {
      print(event.date);
      //TODO; buscar en el JSON la info
      // try {
      //   final encodedDate = event.date.toString();
      //   final jsonData = await _getJsonData(
      //       endPoint: '/weather-api', formattedDate: encodedDate);
      //   final getApiInfo = ApiResponse.fromJson(jsonData);
      //   // print('Aqui va la info $apiInfo');
      //   emit(ApiSetState(apiResponseNew: getApiInfo));
      // } catch (e) {
      //   print(e);
      // }
    });
  }

  // ignore: unused_element
  Future<String> _getJsonData(
      {required String endPoint, required String formattedDate}) async {
    final url = Uri.http(_baseUrl, endPoint, {
      'date': formattedDate,
    });
    final response = await http.get(url);
    return response.body;
  }
}
